import os
import re
import json
import pdfplumber
import pandas as pd
from openai import OpenAI
from sklearn.ensemble import RandomForestRegressor
from dotenv import load_dotenv

load_dotenv(override=True)

# ==========================================
# CONFIGURACIÓN
# ==========================================

client = OpenAI(api_key=os.environ.get('OPENAI_API_KEY'))
DATASET_FILE = "dataset_consumo.csv"

BIMESTRE_NOMBRE = {
    1: "DIC-FEB", 2: "FEB-ABR", 3: "ABR-JUN",
    4: "JUN-AGO", 5: "AGO-OCT", 6: "OCT-DIC"
}

# ==========================================
# VALIDAR RECIBO CFE
# ==========================================

def validar_recibo_cfe(ruta_pdf):

    texto = ""

    with pdfplumber.open(ruta_pdf) as pdf:
        for page in pdf.pages:
            texto += page.extract_text() or ""

    palabras_clave = [
        "CFE",
        "Comisión Federal de Electricidad",
        "Número de servicio",
        "Total a pagar"
    ]

    for palabra in palabras_clave:
        if palabra.lower() in texto.lower():
            return True, "Recibo CFE válido"

    return False, "No parece recibo CFE"

# ==========================================
# EXTRAER DATOS CON OPENAI
# ==========================================

def _extraer_contexto_pdfplumber(ruta_pdf):
    """
    Pre-extrae texto y tablas con pdfplumber para dárselo al modelo como
    contexto estructurado. Ayuda especialmente con PDFs que tienen
    codificación de fuentes no estándar.
    """
    texto_limpio = []
    tablas_formateadas = []

    with pdfplumber.open(ruta_pdf) as pdf:
        for i, page in enumerate(pdf.pages):
            # Texto plano (filtramos páginas con mucho ruido)
            texto = page.extract_text() or ""
            lineas_legibles = [
                l.strip() for l in texto.splitlines()
                if len(l.strip()) > 3 and sum(c.isalnum() for c in l) / max(len(l), 1) > 0.4
            ]
            if lineas_legibles:
                texto_limpio.append(f"[Pág {i+1}]\n" + "\n".join(lineas_legibles))

            # Tablas estructuradas (muy útil para el historial de consumos)
            for tabla in (page.extract_tables() or []):
                filas = []
                for fila in tabla:
                    if fila and any(c for c in fila if c):
                        filas.append(" | ".join(str(c or "").strip() for c in fila))
                if len(filas) > 1:
                    tablas_formateadas.append("\n".join(filas))

    contexto = ""
    if texto_limpio:
        contexto += "TEXTO LEGIBLE DEL PDF:\n" + "\n\n".join(texto_limpio)
    if tablas_formateadas:
        contexto += "\n\nTABLAS DETECTADAS EN EL PDF:\n" + "\n---\n".join(tablas_formateadas)
    return contexto


def extraer_datos_recibo_openai(ruta_pdf):

    # Contexto estructurado pre-extraído por pdfplumber
    contexto_pdf = _extraer_contexto_pdfplumber(ruta_pdf)

    # Subir el PDF para que gpt-4o también lo renderice visualmente
    archivo = client.files.create(
        file=open(ruta_pdf, "rb"),
        purpose="user_data"
    )

    prompt = f"""Analiza este recibo de CFE (Comisión Federal de Electricidad, México).
Tienes dos fuentes: el PDF adjunto (renderizado visual) y el texto/tablas pre-extraídos abajo.
Usa AMBAS fuentes. Si hay conflicto, prioriza lo que puedas leer con claridad en el PDF visual.

Devuelve ÚNICAMENTE un JSON válido con esta estructura, sin texto adicional ni bloques de código:

{{
  "numero_servicio": "",
  "direccion": "",
  "tarifa": "",
  "periodo": "",
  "energia_kwh": "",
  "total_pagar": "",
  "historial_consumos": [
    {{ "periodo": "", "kwh": "", "importe": "" }}
  ]
}}

═══ REGLAS POR CAMPO ═══

"numero_servicio"
  - Es el identificador del PUNTO DE SUMINISTRO eléctrico.
  - Busca exactamente la etiqueta "NO. DE SERVICIO", "Número de servicio" o "N° servicio".
  - Cópialo dígito por dígito, sin omitir ni agregar ninguno.
  - NO es: RMU, CUENTA, folio de pago, número de contrato, ni número de medidor.
  - Ejemplo de este recibo: busca la línea que empieza con "NO. DE SERVICIO:" y copia ese valor.

"tarifa"
  - La CLASIFICACIÓN TARIFARIA CFE. Ejemplos válidos: "1", "1C", "1F", "DAC", "2", "3", "OM", "HM".
  - Busca la etiqueta "TARIFA:" en el recibo. Es un código corto (1-3 caracteres).
  - El recibo también muestra "NO. MEDIDOR:" con un código diferente — ESE NO ES LA TARIFA.
  - NUNCA uses el número de medidor, código de ruta, ni ninguna cadena larga como tarifa.

"periodo"
  - Periodo de facturación ACTUAL: desde la lectura anterior hasta la lectura actual.
  - Busca "PERIODO FACTURADO:" en el recibo.
  - Formato: "del DD MMM AA al DD MMM AA"  (ejemplo: "del 04 FEB 26 al 06 ABR 26")
  - MMM = abreviatura 3 letras español: ENE FEB MAR ABR MAY JUN JUL AGO SEP OCT NOV DIC
  - Inicio y fin DEBEN ser fechas distintas.

"energia_kwh"
  - kWh totales del periodo actual (diferencia entre lectura actual y anterior). Solo número.

"total_pagar"
  - Importe total a pagar. Solo número sin "$" ni comas.

"historial_consumos"
  - Extrae TODOS los periodos de la tabla "CONSUMO HISTÓRICO" del recibo.
  - Esta tabla generalmente está en la segunda página.
  - Incluye CADA fila de la tabla — no omitas ninguna.
  - NO incluyas el periodo actual (ya está en los campos anteriores).
  - NO incluyas filas de pagos, adeudos ni totales.
  - Por cada fila:
      "periodo": "del DD MMM AA al DD MMM AA"
      "kwh": consumo en kWh, solo número.
      "importe": importe en MXN, solo número sin "$" ni comas.

═══ DATOS PRE-EXTRAÍDOS (referencia adicional) ═══
{contexto_pdf}
"""

    response = client.responses.create(
        model="gpt-4o",
        input=[{
            "role": "user",
            "content": [
                {"type": "input_text", "text": prompt},
                {"type": "input_file", "file_id": archivo.id}
            ]
        }]
    )

    return response.output_text

# ==========================================
# PARSEAR PERIODO
# ==========================================

MAPA_BIMESTRE = {
    "ENE": 1, "FEB": 1,
    "MAR": 2, "ABR": 2,
    "MAY": 3, "JUN": 3,
    "JUL": 4, "AGO": 4,
    "SEP": 5, "OCT": 5,
    "NOV": 6, "DIC": 6
}

def parse_periodo(periodo):
    """
    Parsea cualquier formato de periodo que contenga 'MMM YY[YY]' con o sin día.
    Ejemplos soportados:
      'del 03 OCT 25 al 04 DIC 25'
      'del ENE 23 al FEB 23'       ← sin día
      '04 DIC 25-04 FEB 26'
      '03 OCT 2025 al 04 DIC 2025'
    Usa el ÚLTIMO par (mes, año) encontrado (fin de periodo).
    Devuelve (año_4_digitos, bimestre).
    """
    try:
        meses = "|".join(MAPA_BIMESTRE.keys())
        # Acepta día opcional: '(\d{1,2}\s+)?' antes del mes
        patron = rf'(?:\d{{1,2}}\s+)?({meses})\s+(\d{{2,4}})'
        coincidencias = re.findall(patron, periodo.upper())

        if not coincidencias:
            return None, None

        mes, año_str = coincidencias[-1]
        año = int(año_str)
        if año < 100:
            año += 2000

        return año, MAPA_BIMESTRE[mes]
    except Exception:
        return None, None

# ==========================================
# GUARDAR DATASET
# ==========================================

def guardar_dataset(datos_json):

    datos_json = datos_json.replace("```json", "").replace("```", "").strip()

    try:
        datos = json.loads(datos_json)
    except Exception as e:
        print("Error leyendo JSON:", e)
        return None

    historial = datos.get("historial_consumos", [])
    filas = []

    for consumo in historial:

        try:
            kwh = float(str(consumo.get("kwh", "")).replace(",", ""))
        except Exception:
            kwh = None

        try:
            importe = float(str(consumo.get("importe", "")).replace("$", "").replace(",", ""))
        except Exception:
            importe = None

        periodo = consumo.get("periodo", "")
        año, bimestre = parse_periodo(periodo)

        filas.append({
            "numero_servicio": datos.get("numero_servicio"),
            "tarifa": datos.get("tarifa"),
            "periodo": periodo,
            "año": año,
            "bimestre": bimestre,
            "consumo_kwh": kwh,
            "total_pagar": importe
        })

    # Guardar también el periodo actual del recibo (no está en historial_consumos)
    try:
        periodo_actual = datos.get("periodo", "")
        kwh_actual  = float(str(datos.get("energia_kwh", "")).replace(",", "").strip())
        pago_actual = float(str(datos.get("total_pagar", "")).replace("$", "").replace(",", "").strip())
        año_act, bim_act = parse_periodo(periodo_actual)
        filas.append({
            "numero_servicio": datos.get("numero_servicio"),
            "tarifa":          datos.get("tarifa"),
            "periodo":         periodo_actual,
            "año":             año_act,
            "bimestre":        bim_act,
            "consumo_kwh":     kwh_actual,
            "total_pagar":     pago_actual,
        })
    except Exception:
        pass

    df_nuevo = pd.DataFrame(filas)

    if os.path.exists(DATASET_FILE) and os.path.getsize(DATASET_FILE) > 0:
        df_existente = pd.read_csv(DATASET_FILE)
        # Deduplicar: reemplazar filas existentes con mismo servicio + periodo
        clave_existente = df_existente["numero_servicio"].astype(str) + "|" + df_existente["periodo"]
        clave_nueva = df_nuevo["numero_servicio"].astype(str) + "|" + df_nuevo["periodo"]
        df_existente = df_existente[~clave_existente.isin(clave_nueva)]
        df_total = pd.concat([df_existente, df_nuevo], ignore_index=True)
    else:
        df_total = df_nuevo

    df_total.to_csv(DATASET_FILE, index=False)
    return df_total

# ==========================================
# FEATURE ENGINEERING
# ==========================================

def preparar_datos(df):

    df = df.dropna(subset=["consumo_kwh", "total_pagar", "año", "bimestre"])
    df = df[df["bimestre"] != 0]
    df = df.sort_values(["numero_servicio", "año", "bimestre"]).reset_index(drop=True)

    grp = df.groupby("numero_servicio")
    df["consumo_prev_1"] = grp["consumo_kwh"].shift(1)
    df["consumo_prev_2"] = grp["consumo_kwh"].shift(2)
    df["consumo_prev_3"] = grp["consumo_kwh"].shift(3)
    df["costo_prev_1"]   = grp["total_pagar"].shift(1)

    # Costo del mismo bimestre el año anterior: ancla la predicción a
    # la estacionalidad real sin depender del número de año (que RF no extrapola)
    df["costo_mismo_bim_ant"] = df.groupby(
        ["numero_servicio", "bimestre"]
    )["total_pagar"].shift(1)

    # Fallback: si no hay año anterior para ese bimestre, usar costo_prev_1
    df["costo_mismo_bim_ant"] = df["costo_mismo_bim_ant"].fillna(df["costo_prev_1"])

    df = df.dropna(subset=["consumo_prev_1", "consumo_prev_2", "consumo_prev_3", "costo_prev_1"])
    return df

# ==========================================
# ENTRENAR MODELOS
# ==========================================

def entrenar_modelos(df):

    df_prep = preparar_datos(df)
    n = len(df_prep)
    n_estimators = min(100, max(10, n * 3))

    # --- MODELO CONSUMO ---
    X_cons = df_prep[["consumo_prev_1", "consumo_prev_2", "consumo_prev_3", "bimestre"]]
    y_cons = df_prep["consumo_kwh"]

    modelo_consumo = RandomForestRegressor(n_estimators=n_estimators, random_state=42)
    modelo_consumo.fit(X_cons, y_cons)

    # --- MODELO COSTO ---
    # Features: consumo, estacionalidad, costo anterior y costo del mismo bimestre
    # el año pasado. Se omite "año" porque RandomForest no extrapola fuera del rango
    # de entrenamiento — costo_mismo_bim_ant captura la tendencia de precios CFE.
    df_cost = pd.get_dummies(df_prep, columns=["tarifa"])
    tarifa_cols = sorted([c for c in df_cost.columns if c.startswith("tarifa_")])
    cost_features = ["consumo_kwh", "bimestre", "costo_prev_1", "costo_mismo_bim_ant"] + tarifa_cols

    X_cost = df_cost[cost_features]
    y_cost = df_cost["total_pagar"]

    modelo_costo = RandomForestRegressor(n_estimators=n_estimators, random_state=42)
    modelo_costo.fit(X_cost, y_cost)

    return modelo_consumo, modelo_costo, cost_features, tarifa_cols

# ==========================================
# PREDICCIÓN
# ==========================================

def predecir(df, numero_servicio, modelos):

    modelo_consumo, modelo_costo, cost_features, tarifa_cols = modelos

    df_usuario = df[df["numero_servicio"] == numero_servicio].dropna(
        subset=["consumo_kwh", "total_pagar", "año", "bimestre"]
    )
    df_usuario = df_usuario[df_usuario["bimestre"] != 0]
    df_usuario = df_usuario.sort_values(["año", "bimestre"])

    if len(df_usuario) < 4:
        return None

    ultimo = df_usuario.iloc[-1]
    prev1  = df_usuario.iloc[-2]
    prev2  = df_usuario.iloc[-3]

    bim_actual = int(ultimo["bimestre"])
    siguiente_bim = (bim_actual % 6) + 1
    siguiente_año = int(ultimo["año"]) + (1 if bim_actual == 6 else 0)

    # Predicción de consumo
    X_cons = pd.DataFrame([{
        "consumo_prev_1": ultimo["consumo_kwh"],
        "consumo_prev_2": prev1["consumo_kwh"],
        "consumo_prev_3": prev2["consumo_kwh"],
        "bimestre":       siguiente_bim,
    }])
    consumo_pred = modelo_consumo.predict(X_cons)[0]

    # Predicción de costo con features explícitas
    # costo_mismo_bim_ant: buscar el último registro conocido del bimestre siguiente
    mismo_bim = df_usuario[df_usuario["bimestre"] == siguiente_bim]
    if len(mismo_bim) > 0:
        costo_mismo_bim_ant = float(mismo_bim.iloc[-1]["total_pagar"])
    else:
        costo_mismo_bim_ant = float(ultimo["total_pagar"])  # fallback

    tarifa = str(ultimo["tarifa"])
    fila_cost = {
        "consumo_kwh":        consumo_pred,
        "bimestre":           siguiente_bim,
        "costo_prev_1":       float(ultimo["total_pagar"]),
        "costo_mismo_bim_ant": costo_mismo_bim_ant,
    }
    for col in tarifa_cols:
        fila_cost[col] = 1 if col == f"tarifa_{tarifa}" else 0

    X_cost = pd.DataFrame([fila_cost])[cost_features]
    costo_pred = modelo_costo.predict(X_cost)[0]

    return {
        "consumo_estimado":    float(consumo_pred),
        "costo_estimado":      float(costo_pred),
        "ultimo_costo":        float(ultimo["total_pagar"]),
        "ultimo_consumo":      float(ultimo["consumo_kwh"]),
        "siguiente_bimestre":  siguiente_bim,
        "siguiente_año":       siguiente_año,
        "registros_historicos": len(df_usuario),
    }

# ==========================================
# GENERAR JSON FINAL
# ==========================================

def generar_json(datos, pred):

    diff = pred["costo_estimado"] - pred["ultimo_costo"]
    pct  = (diff / pred["ultimo_costo"] * 100) if pred["ultimo_costo"] else 0

    resultado = {
        "numero_servicio": datos["numero_servicio"],
        "tarifa":          datos["tarifa"],
        "periodo_actual":  datos["periodo"],
        "siguiente_periodo": BIMESTRE_NOMBRE.get(pred["siguiente_bimestre"], ""),

        "prediccion": {
            "consumo_estimado_kwh": round(pred["consumo_estimado"], 1),
            "costo_estimado":       round(pred["costo_estimado"], 2),
        },

        "comparacion": {
            "ultimo_costo":       pred["ultimo_costo"],
            "ultimo_consumo_kwh": pred["ultimo_consumo"],
            "diferencia":         round(diff, 2),
            "porcentaje":         round(pct, 1),
            "tendencia":          "sube" if diff > 0 else "baja",
        },

        "datos_suficientes": pred["registros_historicos"] >= 6,
    }

    if pred["registros_historicos"] < 6:
        resultado["advertencia"] = (
            f"Predicción basada en {pred['registros_historicos']} bimestres. "
            "La precisión mejorará con más historial."
        )

    return resultado

# ==========================================
# PIPELINE COMPLETO
# ==========================================

def procesar_recibo(archivo):

    print("\nProcesando:", archivo)

    valido, mensaje = validar_recibo_cfe(archivo)
    print("Validación:", mensaje)

    if not valido:
        return None

    print("\nAnalizando con OpenAI...\n")
    datos_raw = extraer_datos_recibo_openai(archivo)
    print("Datos extraídos:\n", datos_raw)

    df = guardar_dataset(datos_raw)
    if df is None:
        return None

    modelos = entrenar_modelos(df)
    datos   = json.loads(datos_raw.replace("```json", "").replace("```", "").strip())

    pred = predecir(df, datos["numero_servicio"], modelos)
    if pred is None:
        print("No hay suficiente historial para predecir (mínimo 4 bimestres)")
        return None

    resultado = generar_json(datos, pred)
    print("\nRESULTADO FINAL:\n")
    print(json.dumps(resultado, indent=4, ensure_ascii=False))
    return resultado

# ==========================================
# PROCESAR CARPETA
# ==========================================

def procesar_carpeta():

    carpeta = "recibos"

    if not os.path.exists(carpeta):
        print("La carpeta 'recibos' no existe.")
        return

    for archivo in os.listdir(carpeta):
        if archivo.lower().endswith(".pdf"):
            ruta = os.path.join(carpeta, archivo)
            procesar_recibo(ruta)

# ==========================================
# MAIN
# ==========================================

if __name__ == "__main__":
    procesar_carpeta()
