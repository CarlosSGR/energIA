import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import psycopg2
import psycopg2.extras
from psycopg2 import errors as pg_errors
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import hashlib
from datetime import datetime
from dotenv import load_dotenv

from validar_pdf import (
    validar_recibo_cfe, extraer_datos_recibo_openai,
    guardar_dataset, entrenar_modelos, predecir, generar_json
)
import json as json_module

load_dotenv(override=True)

app = Flask(__name__)
CORS(app)

DATABASE_URL = os.environ.get('DATABASE_URL')

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def get_db_connection():
    return psycopg2.connect(DATABASE_URL)

@app.route('/api/registro', methods=['POST'])
def registro():
    data = request.json
    nombres     = data.get('nombres')
    apellidos   = data.get('apellidos')
    correo      = data.get('correo')
    contrasena  = data.get('contrasena')
    telegram    = data.get('telegram') or None

    # Normalizar teléfono: eliminar todo excepto dígitos tras +52, forzar formato +52XXXXXXXXXX
    telefono_raw = data.get('telefono', '').strip()
    digitos = telefono_raw.lstrip('+')
    if digitos.startswith('52'):
        digitos = digitos[2:]
    digitos = ''.join(c for c in digitos if c.isdigit())
    if len(digitos) != 10:
        return jsonify({"status": "error", "message": "El teléfono debe tener exactamente 10 dígitos (México)."}), 400
    telefono = '+52' + digitos

    acepta_notificaciones = True if data.get('notificaciones') else False
    contrasena_hash = generate_password_hash(contrasena)
    fecha_registro  = datetime.now()
    rol_default     = 1

    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor()

        query = """
            INSERT INTO "Usuario"
                ("Rol", "Nombres", "Apellidos", "Correo", "Contrasena", "FechaRegistro", "Telefono", "AceptaNotificaciones", "TelegramChatId")
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (
            rol_default, nombres, apellidos, correo,
            contrasena_hash, fecha_registro, telefono,
            acepta_notificaciones, telegram
        ))
        conn.commit()

        return jsonify({"status": "success", "message": "Usuario registrado correctamente"}), 201

    except pg_errors.UniqueViolation:
        if conn: conn.rollback()
        return jsonify({"status": "error", "message": "El correo ya está registrado"}), 409
    except pg_errors.ForeignKeyViolation:
        if conn: conn.rollback()
        return jsonify({"status": "error", "message": "Error interno: El Rol por defecto no existe en la base de datos"}), 500
    except Exception as e:
        if conn: conn.rollback()
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

@app.route('/api/login', methods=['POST'])
def login():
    data       = request.json
    correo     = data.get('correo')
    contrasena = data.get('contrasena')

    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        query = """SELECT "Id", "Nombres", "Contrasena", "Rol" FROM "Usuario" WHERE "Correo" = %s"""
        cursor.execute(query, (correo,))
        usuario = cursor.fetchone()

        if usuario and check_password_hash(usuario['Contrasena'], contrasena):
            return jsonify({
                "status": "success",
                "userId": usuario['Id'],
                "nombre": usuario['Nombres'],
                "rol":    usuario['Rol']
            }), 200
        else:
            return jsonify({"status": "error", "message": "Credenciales inválidas"}), 401

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

# ==========================================
# ENDPOINT DE SUBIDA Y VALIDACIÓN
# ==========================================
@app.route('/api/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"status": "error", "message": "No se envió ningún archivo"}), 400

    file    = request.files['file']
    user_id = request.form.get('userId')

    if file.filename == '':
        return jsonify({"status": "error", "message": "Archivo no seleccionado"}), 400

    if not file.filename.lower().endswith('.pdf'):
        return jsonify({"status": "error", "message": "Solo se permiten archivos PDF"}), 400

    filepath = None
    conn     = None
    cursor   = None
    try:
        filename        = secure_filename(file.filename)
        timestamp       = datetime.now().strftime('%Y%m%d%H%M%S')
        unique_filename = f"{user_id}_{timestamp}_{filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)

        file.save(filepath)

        # Calcular hash del archivo para detectar duplicados
        sha256 = hashlib.sha256()
        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        file_hash = sha256.hexdigest()

        # Verificar si este usuario ya subió el mismo archivo
        conn_dup   = get_db_connection()
        cursor_dup = conn_dup.cursor()
        cursor_dup.execute(
            """SELECT "Id" FROM "Recibos" WHERE "UsuarioId" = %s AND "Hash" = %s LIMIT 1""",
            (user_id, file_hash)
        )
        duplicado = cursor_dup.fetchone()
        cursor_dup.close()
        conn_dup.close()

        if duplicado:
            os.remove(filepath)
            return jsonify({"status": "error", "message": "Este recibo ya fue subido anteriormente."}), 409

        es_valido, mensaje_validacion = validar_recibo_cfe(filepath)

        if not es_valido:
            os.remove(filepath)
            return jsonify({"status": "error", "message": mensaje_validacion}), 400

        conn   = get_db_connection()
        cursor = conn.cursor()
        fecha_subida = datetime.now().strftime('%Y-%m-%d')

        query = """
            INSERT INTO "Recibos" ("UsuarioId", "Url", "FechaSubida", "Estado", "Hash")
            VALUES (%s, %s, %s, %s, %s)
            RETURNING "Id"
        """
        cursor.execute(query, (user_id, filepath, fecha_subida, 'Subido y Validado', file_hash))
        recibo_id = cursor.fetchone()[0]
        conn.commit()
        cursor.close()
        conn.close()
        conn = None
        cursor = None

        # 4. Pipeline de IA: extracción + predicción
        prediccion_resultado = None
        try:
            datos_raw = extraer_datos_recibo_openai(filepath)
            df        = guardar_dataset(datos_raw)
            datos     = json_module.loads(datos_raw.replace("```json", "").replace("```", "").strip())

            # Extraer consumo y costo del recibo actual
            kwh = None
            costo_val = None
            try:
                kwh = float(str(datos.get('energia_kwh', '')).replace(',', '').strip())
            except Exception:
                pass
            try:
                costo_val = float(str(datos.get('total_pagar', '')).replace('$', '').replace(',', '').strip())
            except Exception:
                pass

            # Actualizar Recibos con los datos extraídos
            conn2   = get_db_connection()
            cursor2 = conn2.cursor()
            cursor2.execute(
                """UPDATE "Recibos" SET "Consumo"=%s, "Costo"=%s, "Estado"=%s WHERE "Id"=%s""",
                (kwh, costo_val, 'Analizado', recibo_id)
            )
            conn2.commit()
            cursor2.close()
            conn2.close()

            # Intentar predicción (requiere mínimo 4 bimestres de historial)
            if df is not None and len(df) >= 4:
                modelos = entrenar_modelos(df)
                pred    = predecir(df, datos.get('numero_servicio'), modelos)
                if pred:
                    prediccion_resultado = generar_json(datos, pred)
                    comp = prediccion_resultado.get('comparacion', {})

                    conn3   = get_db_connection()
                    cursor3 = conn3.cursor()
                    cursor3.execute("""
                        INSERT INTO "Prediccion" (
                            "ReciboId", "ConsumoEstimado", "CostoEstimado", "FechaGenerada",
                            "SiguientePeriodo", "PeriodoActual", "NumeroServicio", "Tarifa",
                            "UltimoCosto", "UltimoConsumo", "Diferencia", "Porcentaje",
                            "Tendencia", "DatosSuficientes", "Advertencia"
                        ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    """, (
                        recibo_id,
                        pred['consumo_estimado'],
                        pred['costo_estimado'],
                        datetime.now(),
                        prediccion_resultado.get('siguiente_periodo'),
                        prediccion_resultado.get('periodo_actual'),
                        prediccion_resultado.get('numero_servicio'),
                        prediccion_resultado.get('tarifa'),
                        comp.get('ultimo_costo'),
                        comp.get('ultimo_consumo_kwh'),
                        comp.get('diferencia'),
                        comp.get('porcentaje'),
                        comp.get('tendencia'),
                        prediccion_resultado.get('datos_suficientes'),
                        prediccion_resultado.get('advertencia')
                    ))
                    conn3.commit()
                    cursor3.close()
                    conn3.close()

        except Exception as e:
            print(f"[AI Pipeline] Error: {e}")
            # No fallamos el upload, solo registramos el error

        msg = "Archivo subido, validado y analizado con IA" if prediccion_resultado else "Archivo subido y validado correctamente"
        return jsonify({
            "status": "success",
            "message": msg,
            "file": {
                "id":   recibo_id,
                "name": filename,
                "date": fecha_subida
            },
            "prediccion": prediccion_resultado
        }), 201

    except Exception as e:
        if conn: conn.rollback()
        if filepath and os.path.exists(filepath):
            os.remove(filepath)
        return jsonify({"status": "error", "message": f"Error al procesar el archivo: {str(e)}"}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

@app.route('/api/recibos/<int:user_id>', methods=['GET'])
def obtener_recibos(user_id):
    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""
            SELECT r."Id", r."Url", r."FechaSubida", r."Estado",
                   p."NumeroServicio", p."PeriodoActual"
            FROM "Recibos" r
            LEFT JOIN "Prediccion" p ON p."ReciboId" = r."Id"
            WHERE r."UsuarioId" = %s
            ORDER BY p."NumeroServicio" ASC NULLS LAST, r."FechaSubida" DESC
        """, (user_id,))
        recibos = cursor.fetchall()

        archivos_formateados = []
        for r in recibos:
            filename_part   = os.path.basename(r['Url'])
            partes          = filename_part.split('_', 2)
            nombre_original = partes[2] if len(partes) > 2 else filename_part

            archivos_formateados.append({
                "id":              r['Id'],
                "name":            nombre_original,
                "date":            r['FechaSubida'].strftime('%Y-%m-%d'),
                "estado":          r['Estado'],
                "url":             f"http://127.0.0.1:5000/api/uploads/{filename_part}",
                "numero_servicio": r['NumeroServicio'],
                "periodo_actual":  r['PeriodoActual'],
            })

        return jsonify({"status": "success", "archivos": archivos_formateados}), 200

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

# RUTA PARA VER LOS PDF
@app.route('/api/uploads/<path:filename>', methods=['GET'])
def serve_pdf(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/api/recibos/<int:recibo_id>', methods=['DELETE'])
def eliminar_recibo(recibo_id):
    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""SELECT "Url" FROM "Recibos" WHERE "Id" = %s""", (recibo_id,))
        recibo = cursor.fetchone()

        if recibo:
            filepath = recibo['Url']
            if filepath and os.path.exists(filepath):
                os.remove(filepath)

            cursor2 = conn.cursor()
            cursor2.execute("""DELETE FROM "Prediccion" WHERE "ReciboId" = %s""", (recibo_id,))
            cursor2.execute("""DELETE FROM "Recibos"    WHERE "Id" = %s""", (recibo_id,))
            conn.commit()
            cursor2.close()

            return jsonify({"status": "success", "message": "Recibo eliminado correctamente"}), 200
        else:
            return jsonify({"status": "error", "message": "Recibo no encontrado"}), 404

    except Exception as e:
        if conn: conn.rollback()
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

# ==========================================
# NÚMEROS DE SERVICIO DEL USUARIO
# ==========================================
@app.route('/api/servicios/<int:user_id>', methods=['GET'])
def obtener_servicios(user_id):
    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute("""
            SELECT DISTINCT p."NumeroServicio", p."Tarifa",
                   MAX(p."FechaGenerada") AS "UltimaPrediccion"
            FROM "Prediccion" p
            JOIN "Recibos" r ON p."ReciboId" = r."Id"
            WHERE r."UsuarioId" = %s AND p."NumeroServicio" IS NOT NULL
            GROUP BY p."NumeroServicio", p."Tarifa"
            ORDER BY "UltimaPrediccion" DESC
        """, (user_id,))
        rows = cursor.fetchall()
        servicios = [
            {
                "numero_servicio": row['NumeroServicio'],
                "tarifa":          row['Tarifa'],
            }
            for row in rows
        ]
        return jsonify({"status": "success", "servicios": servicios}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

# ==========================================
# PREDICCIÓN
# ==========================================
@app.route('/api/prediccion/<int:user_id>', methods=['GET'])
def obtener_prediccion(user_id):
    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        numero_servicio = request.args.get('numeroServicio')

        # Predicción más reciente del usuario (filtrada por N° servicio si se indica)
        if numero_servicio:
            cursor.execute("""
                SELECT p."ConsumoEstimado", p."CostoEstimado", p."FechaGenerada",
                       p."NumeroServicio", p."SiguientePeriodo", p."PeriodoActual",
                       p."Tarifa", p."DatosSuficientes", p."Advertencia",
                       p."UltimoCosto", p."UltimoConsumo",
                       p."Diferencia", p."Porcentaje", p."Tendencia",
                       r."Consumo" AS "ConsumoActual", r."Costo" AS "CostoActual"
                FROM "Prediccion" p
                JOIN "Recibos" r ON p."ReciboId" = r."Id"
                WHERE r."UsuarioId" = %s AND p."NumeroServicio" = %s
                ORDER BY p."FechaGenerada" DESC
                LIMIT 1
            """, (user_id, numero_servicio))
        else:
            cursor.execute("""
                SELECT p."ConsumoEstimado", p."CostoEstimado", p."FechaGenerada",
                       p."NumeroServicio", p."SiguientePeriodo", p."PeriodoActual",
                       p."Tarifa", p."DatosSuficientes", p."Advertencia",
                       p."UltimoCosto", p."UltimoConsumo",
                       p."Diferencia", p."Porcentaje", p."Tendencia",
                       r."Consumo" AS "ConsumoActual", r."Costo" AS "CostoActual"
                FROM "Prediccion" p
                JOIN "Recibos" r ON p."ReciboId" = r."Id"
                WHERE r."UsuarioId" = %s
                ORDER BY p."FechaGenerada" DESC
                LIMIT 1
            """, (user_id,))
        pred = cursor.fetchone()

        if not pred:
            return jsonify({"status": "success", "prediccion": None, "historial": []}), 200

        costo_est   = float(pred['CostoEstimado'])   if pred['CostoEstimado']   else None
        consumo_est = float(pred['ConsumoEstimado']) if pred['ConsumoEstimado'] else None
        costo_act   = float(pred['CostoActual'])     if pred['CostoActual']     else None
        consumo_act = float(pred['ConsumoActual'])   if pred['ConsumoActual']   else None

        # Prefer DB-stored values; fall back to live calculation
        diferencia = float(pred['Diferencia']) if pred['Diferencia'] is not None else (
            round(costo_est - costo_act, 2) if (costo_est and costo_act) else None
        )
        porcentaje = float(pred['Porcentaje']) if pred['Porcentaje'] is not None else (
            round(diferencia / costo_act * 100, 1) if (diferencia is not None and costo_act) else None
        )
        tendencia  = pred['Tendencia'] or (
            ("sube" if diferencia > 0 else "baja") if diferencia is not None else None
        )

        # Historial + conteo filtrado por número de servicio
        num_serv_filtro = numero_servicio or (pred['NumeroServicio'] if pred else None)
        if num_serv_filtro:
            cursor.execute("""
                SELECT r."Consumo", r."Costo", r."FechaSubida"
                FROM "Recibos" r
                JOIN "Prediccion" p ON p."ReciboId" = r."Id"
                WHERE r."UsuarioId" = %s AND p."NumeroServicio" = %s
                  AND r."Consumo" IS NOT NULL
                ORDER BY r."FechaSubida" ASC
            """, (user_id, num_serv_filtro))
        else:
            cursor.execute("""
                SELECT "Consumo", "Costo", "FechaSubida"
                FROM "Recibos"
                WHERE "UsuarioId" = %s AND "Consumo" IS NOT NULL
                ORDER BY "FechaSubida" ASC
            """, (user_id,))
        historial_rows = cursor.fetchall()
        historial = [
            {
                "consumo": float(h['Consumo']) if h['Consumo'] else None,
                "costo":   float(h['Costo'])   if h['Costo']   else None,
                "fecha":   h['FechaSubida'].strftime('%Y-%m-%d') if h['FechaSubida'] else None
            }
            for h in historial_rows
        ]
        total_recibos = len(historial_rows)

        return jsonify({
            "status": "success",
            "prediccion": {
                "costo_estimado":    costo_est,
                "consumo_estimado":  consumo_est,
                "costo_actual":      costo_act,
                "consumo_actual":    consumo_act,
                "diferencia":        diferencia,
                "porcentaje":        porcentaje,
                "tendencia":         tendencia,
                "fecha_generada":    pred['FechaGenerada'].strftime('%Y-%m-%d') if pred['FechaGenerada'] else None,
                "numero_servicio":   pred['NumeroServicio'],
                "periodo_actual":    pred['PeriodoActual'],
                "siguiente_periodo": pred['SiguientePeriodo'],
                "tarifa":            pred['Tarifa'],
                "datos_suficientes": pred['DatosSuficientes'],
                "advertencia":       pred['Advertencia'],
                "ultimo_costo":      float(pred['UltimoCosto'])   if pred['UltimoCosto']   else None,
                "ultimo_consumo":    float(pred['UltimoConsumo']) if pred['UltimoConsumo'] else None,
            },
            "historial":      historial,
            "total_recibos":  total_recibos,
        }), 200

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

# ==========================================
# HELPERS Y ENDPOINTS DE ADMINISTRADOR
# ==========================================
def verificar_admin(admin_id):
    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute("""SELECT "Rol" FROM "Usuario" WHERE "Id" = %s""", (admin_id,))
        user = cursor.fetchone()
        return user is not None and user['Rol'] == 2
    except Exception:
        return False
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

@app.route('/api/admin/usuarios', methods=['GET'])
def admin_get_usuarios():
    admin_id = request.args.get('adminId')
    if not admin_id or not verificar_admin(int(admin_id)):
        return jsonify({"status": "error", "message": "Acceso denegado"}), 403

    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute("""
            SELECT "Id", "Nombres", "Apellidos", "Correo", "Telefono", "FechaRegistro"
            FROM "Usuario"
            WHERE "Rol" = 1
            ORDER BY "Id"
        """)
        usuarios = cursor.fetchall()
        for u in usuarios:
            if u['FechaRegistro']:
                u['FechaRegistro'] = u['FechaRegistro'].strftime('%Y-%m-%d')
        return jsonify({"status": "success", "usuarios": usuarios, "total": len(usuarios)}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

@app.route('/api/admin/usuarios/<int:user_id>', methods=['DELETE'])
def admin_delete_usuario(user_id):
    data     = request.json or {}
    admin_id = data.get('adminId')
    if not admin_id or not verificar_admin(int(admin_id)):
        return jsonify({"status": "error", "message": "Acceso denegado"}), 403

    conn    = None
    cursor  = None
    cursor2 = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

        cursor.execute("""SELECT "Url" FROM "Recibos" WHERE "UsuarioId" = %s""", (user_id,))
        recibos = cursor.fetchall()

        cursor2 = conn.cursor()
        # PostgreSQL no soporta DELETE con JOIN — usamos subquery
        cursor2.execute("""
            DELETE FROM "Prediccion"
            WHERE "ReciboId" IN (SELECT "Id" FROM "Recibos" WHERE "UsuarioId" = %s)
        """, (user_id,))
        cursor2.execute("""DELETE FROM "Recibos"      WHERE "UsuarioId" = %s""", (user_id,))
        cursor2.execute("""DELETE FROM "Analisis"     WHERE "UsuarioId" = %s""", (user_id,))
        cursor2.execute("""DELETE FROM "Notificacion" WHERE "UsuarioId" = %s""", (user_id,))
        cursor2.execute("""DELETE FROM "Errores"      WHERE "UsuarioId" = %s""", (user_id,))
        cursor2.execute("""DELETE FROM "Usuario"      WHERE "Id" = %s AND "Rol" = 1""", (user_id,))
        deleted = cursor2.rowcount
        conn.commit()

        if deleted == 0:
            return jsonify({"status": "error", "message": "Usuario no encontrado"}), 404

        for r in recibos:
            if r['Url'] and os.path.exists(r['Url']):
                os.remove(r['Url'])

        return jsonify({"status": "success", "message": "Usuario eliminado"}), 200
    except Exception as e:
        if conn: conn.rollback()
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor:  cursor.close()
        if cursor2: cursor2.close()
        if conn:    conn.close()

# ==========================================
# TICKETS DE USUARIO
# ==========================================
@app.route('/api/tickets', methods=['POST'])
def crear_ticket():
    data       = request.json or {}
    user_id    = data.get('userId')
    titulo     = data.get('titulo', '').strip()
    mensaje    = data.get('mensaje', '').strip()

    if not user_id or not titulo or not mensaje:
        return jsonify({"status": "error", "message": "Faltan datos requeridos."}), 400

    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO "Errores" ("UsuarioId", "Titulo", "Mensaje", "FechaReporte", "Estatus")
            VALUES (%s, %s, %s, CURRENT_DATE, 'Pendiente')
        """, (user_id, titulo, mensaje))
        conn.commit()
        return jsonify({"status": "success", "message": "Ticket enviado correctamente."}), 201
    except Exception as e:
        if conn: conn.rollback()
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

@app.route('/api/tickets/<int:user_id>', methods=['GET'])
def get_tickets_usuario(user_id):
    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute("""
            SELECT "Id", "Titulo", "Mensaje", "FechaReporte", "Estatus"
            FROM "Errores"
            WHERE "UsuarioId" = %s
            ORDER BY "Id" DESC
        """, (user_id,))
        tickets = cursor.fetchall()
        result  = [
            {
                "id":      t['Id'],
                "titulo":  t['Titulo'],
                "mensaje": t['Mensaje'],
                "fecha":   t['FechaReporte'].strftime('%d/%m/%Y') if t['FechaReporte'] else '—',
                "estatus": t['Estatus'] or 'Pendiente',
            }
            for t in tickets
        ]
        return jsonify({"status": "success", "tickets": result}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

@app.route('/api/admin/tickets', methods=['GET'])
def admin_get_tickets():
    admin_id = request.args.get('adminId')
    if not admin_id or not verificar_admin(int(admin_id)):
        return jsonify({"status": "error", "message": "Acceso denegado"}), 403

    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        cursor.execute("""
            SELECT e."Id", u."Correo", e."Titulo", e."Mensaje", e."FechaReporte", e."Estatus"
            FROM "Errores" e
            JOIN "Usuario" u ON e."UsuarioId" = u."Id"
            ORDER BY e."Id"
        """)
        tickets = cursor.fetchall()
        for t in tickets:
            if t['FechaReporte']:
                t['FechaReporte'] = t['FechaReporte'].strftime('%Y-%m-%d')
        return jsonify({"status": "success", "tickets": tickets, "total": len(tickets)}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

@app.route('/api/admin/tickets/<int:ticket_id>', methods=['PATCH'])
def admin_update_ticket(ticket_id):
    data     = request.json or {}
    admin_id = data.get('adminId')
    estatus  = data.get('estatus', '').strip()

    ESTATUS_VALIDOS = {'Pendiente', 'En revisión', 'Resuelto'}
    if not admin_id or not verificar_admin(int(admin_id)):
        return jsonify({"status": "error", "message": "Acceso denegado"}), 403
    if estatus not in ESTATUS_VALIDOS:
        return jsonify({"status": "error", "message": "Estatus inválido."}), 400

    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""UPDATE "Errores" SET "Estatus" = %s WHERE "Id" = %s""", (estatus, ticket_id))
        conn.commit()
        if cursor.rowcount == 0:
            return jsonify({"status": "error", "message": "Ticket no encontrado"}), 404
        return jsonify({"status": "success", "message": "Estatus actualizado"}), 200
    except Exception as e:
        if conn: conn.rollback()
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

@app.route('/api/admin/tickets/<int:ticket_id>', methods=['DELETE'])
def admin_delete_ticket(ticket_id):
    data     = request.json or {}
    admin_id = data.get('adminId')
    if not admin_id or not verificar_admin(int(admin_id)):
        return jsonify({"status": "error", "message": "Acceso denegado"}), 403

    conn   = None
    cursor = None
    try:
        conn   = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""DELETE FROM "Errores" WHERE "Id" = %s""", (ticket_id,))
        conn.commit()
        if cursor.rowcount == 0:
            return jsonify({"status": "error", "message": "Ticket no encontrado"}), 404
        return jsonify({"status": "success", "message": "Ticket eliminado"}), 200
    except Exception as e:
        if conn: conn.rollback()
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()

if __name__ == '__main__':
    app.run(debug=True, port=5000)
